#include <iostream>
#include <string>
#include "producto.h"

using std::string;
using std::cout;
using std::endl;

producto::producto(){

}

producto::producto(double prec, int cant, string name, string ident){
    prec = precio;
    cantidad = cant;
    nombre = name;
    ident = id;

}

void producto::setPrecio(double pre){
    precio = pre;
}

double producto::getPrecio(){
    return precio;
}

void producto::setID(string ident){
    id = ident;
}

string producto::getID(){
    return id;
}

void producto::setNombre(string name){
    nombre = name;
}

string producto::getNombre(){
    return nombre;
}

void producto::setCant(int cant){
    cantidad = cant;
}

int producto::getCant(){
    return cantidad;
}

void producto::display(){
    cout << nombre << " " << cantidad << " " << precio << endl;
}