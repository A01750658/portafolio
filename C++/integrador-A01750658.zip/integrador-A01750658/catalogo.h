#ifndef catalogo_h
#define catalogo_h

#include <iostream>
#include <vector>
#include "producto.h"

using std::vector;

class catalogo{
    private:
        vector<producto> stock;
    public:
        catalogo();
        void display();
        void agregarProd(producto p);
        vector<producto> getStock();
};

#endif