#include <iostream>
#include <string>
#include <fstream>
#include <sstream>
#include "lector.h"
#include "producto.h"
#include "catalogo.h"

using std::string;
using std::ifstream;
using std::ofstream;
using std::ios;
using std::stringstream;
using std::cout;
using std::endl;
using std::stoi;
using std::stod;


void lector::read(){
    ifstream file("inventario.csv", ios::in);
    string linea, palabra;
    
    if (file.is_open()){
        
    while(getline(file, linea)){
        stringstream str(linea);
        string id, nombre, precio, cant;
        getline(str, id, ',');
        cout << id << endl;
        getline(str, nombre, ',');
        cout << nombre << endl;
        getline(str, precio, ',');
        cout << precio << endl;
        getline(str, cant, ',');
        
        cout << cant << endl;

        int cant2 = stoi(cant);
        double precio2 = stod(precio); 
        producto prod(precio2, cant2,  nombre, id);
        catalogo c;
        c.agregarProd(prod);

    }

    }


}