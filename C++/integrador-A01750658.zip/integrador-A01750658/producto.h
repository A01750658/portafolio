#ifndef producto_h
#define producto_h

#include <iostream>

using std::string;

class producto{
    private:
        double precio;
        int cantidad;
        string nombre;
        string id;
    
    public:
        producto();
        producto(double prec, int cant, string name, string ident);
        void setPrecio(double pre);
        double getPrecio();
        void setID(string ident);
        string getID();
        void setNombre(string name);
        string getNombre();
        void setCant(int cant);
        int getCant();
        void display();

};

#endif