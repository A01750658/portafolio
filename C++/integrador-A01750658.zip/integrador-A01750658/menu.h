#ifndef menu_h
#define menu_h

class menu{
    public:
        menu();
        void principal();

};

#endif