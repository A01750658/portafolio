#ifndef carrito_h
#define carrito_h

#include <iostream>
#include <vector>
#include "producto.h"
#include "catalogo.h"

using std::vector;

class carrito{
    private: 
        vector<producto> compraLista;
        bool comprar;
        double total;
        catalogo cata;
        producto p;
    public:
        carrito();
        producto getProd();
        void agregarProd(producto p);
        void calcularPrecio();
        void displayProd();
        void displayTotal();

};

#endif