#include <iostream>
#include <vector>
#include "catalogo.h"
#include "producto.h"

using std::string; 
using std::vector;
using std::cout;

catalogo::catalogo(){

}

void catalogo::agregarProd(producto p){
    stock.push_back(p);
}

void catalogo::display(){
    for (int i = 0; i < stock.size(); i++){
        cout << i << " ";
        stock[i].display();
    }
}

vector <producto> catalogo::getStock(){
    return stock;
}