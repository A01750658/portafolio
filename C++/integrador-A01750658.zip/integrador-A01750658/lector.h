#ifndef lector_h
#define lector_h

#include <iostream>
#include <string>
#include <fstream>

using std::string;

class lector{

    public:
        void read();
            
};

#endif