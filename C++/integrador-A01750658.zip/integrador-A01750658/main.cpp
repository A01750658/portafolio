#include <iostream>
#include <fstream>
#include <string>
#include "lector.h"
#include "producto.h"
#include "menu.h"

using std::cout;
using std::endl;
using std::fstream;
using std::string;

int main(){
    menu m;
    m.principal();

}