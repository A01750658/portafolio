#include <iostream>
#include <vector>
#include <string>
#include <stdlib.h>
#include "carrito.h"
#include "lector.h"
#include "producto.h"
#include "catalogo.h"
#include "menu.h"

using std::cout;
using std::endl;
using std::string;
using std::vector;
using std::cin;

menu::menu(){

}

void menu::principal(){
    
    lector l;
    l.read();
    catalogo c;
    carrito car;
    vector<producto> stock;

    
    bool cond = true;
    while (cond){
        int select1;
        cout << "**** MENU PRNCIPAL *****" << endl;
        cout << "1) Seleccionar producto" << endl;
        cout << "2) Ver carrito de compras" << endl;
        cout << "3) Terminar compra" << endl;
        cout << "4) Salir" << endl;
        cout << "Selecciona opción: " << endl;
        cin >> select1;
        switch(select1){
            case 1:
                stock = c.getStock();
                for (int i = 0, i < stock.size(); i++{
                    cout << stock[i] << endl;
                }
                cout << "Qué producto deseas comprar? (-1 para cancelar)" << endl;
                int select2;
                cin >> select2;
                if (select2 == -1){
                    exit(-1);
                }
                else {
                    vector<producto> prods = c.getStock();
                    producto p = prods[select2];
                    cout << "Cuantas unidades deseas comprar? (-1 para salir)" << endl;
                    int cantidad;
                    cin >> cantidad;
                        if (cantidad == -1){
                            exit(-1);
                        }
                        else if (cantidad > p.getCant()){    
                            cout << "No hay suficientes productos para cubrir su compra:" << endl;
                            exit(-1);
                        }
                        else {
                            for (int i = 0; i < cantidad; i++){
                                car.agregarProd(p);
                                
                            }
                            p.setCant(p.getCant() - cantidad);
                            cout << "Se ha agregado el producto al carrito" << endl;
                        }
                }
                break;
            case 2:
                car.displayProd();
                break;
            case 3:
                car.displayTotal();
            case 4:
                exit(0);





        }
    } 
}