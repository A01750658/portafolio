#include <iostream>
#include <vector>
#include <string>
#include "producto.h"
#include "catalogo.h"
#include "carrito.h"

using std::string;
using std::vector;
using std::cout;
using std::endl;

carrito::carrito(){

}



void carrito::agregarProd(producto p){
    compraLista.push_back(p);
}

void carrito::calcularPrecio(){
    for (int i = 0; i <compraLista.size(); i++){
        total = total + compraLista[i].getPrecio();
    }
}

void carrito::displayProd(){
    for (int i = 0; i < total; i++){
        compraLista[i].display();
    }
    
}

void carrito::displayTotal(){
    cout << "El total de su compra es: " << total << endl;
}
