/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Heroes;

import java.util.Scanner;
import java.util.Vector;

/**
 *
 * @author ikerf
 */
public class Academia {
    Scanner in = new Scanner(System.in);
    Vector academia;
    Escuadron e = new Escuadron();
    public Academia() {
       academia = new Vector();
    }
    public void describir_escuadrones(){
        
    }
    public void imprimir(){
        
    }
    
}
