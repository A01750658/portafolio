/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package variables;

/**
 *
 * @author alanvega
 */
public class Variables {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int edad;
        double estatura = 1.80;
        edad = 20;
        String nombre = "alan rodrigo";
        System.out.println("la edad es:" + edad + "mi estatura es:" + estatura + "mi nombre es:" + nombre );
        System.out.println("tu estatura es:"+ estatura);
        System.out.println("tu nombre es:"+nombre);
        
        
        
        
        
        
        int x1 = 25;
        int x2 = 50;
        int suma = x1 + x2;
        System.out.println(suma);
    }
    
}
