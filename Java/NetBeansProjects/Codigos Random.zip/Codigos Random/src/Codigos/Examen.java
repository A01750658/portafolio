/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Codigos;
import java.util.Scanner;
/**
 *
 * @author alanvega
 */
public class Examen {
    public static void main (String [] args){
    Scanner in = new Scanner (System.in);
    System.out.println ("Introduce un número");
    int numero = in.nextInt();        
    if (numero%2 == 0) {
        System.out.println ("el número no es primo");
    }
    else {
        System.out.println ("El número es primo");    
    }
    if (numero%3 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
      System.out.println ("el número es primo"); 
    }
    if (numero%5 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%7 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
      System.out.println ("el número es primo"); 
    }
    if (numero%11 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
      System.out.println ("el número es primo"); 
    }
    if (numero%13 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%17 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%19 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%23 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%29 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    if (numero%31 == 0 ) {
        System.out.println ("El número no es primo");
    }
    else {
       System.out.println ("el número es primo");
    }
    }        
    }